package com.newland.ssm.common;

/**
 * @author wrp
 * @Description com.newland.ssm.common.Common
 * @Date 2017/1/16
 */
public class Constans {

    public final static Integer SUCCESS = 1;
    public final static Integer FAIL = 0;


}
