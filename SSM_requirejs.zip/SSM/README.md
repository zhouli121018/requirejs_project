本示例采用框架、插件：
后端：SpringMvc、MyBatis、Spring
前端：requirejs、jQuery、jQuery-validation、bootstrap、bootstrap-table、bootstrap-datetimepicker、json2、underscore、select2、zTree